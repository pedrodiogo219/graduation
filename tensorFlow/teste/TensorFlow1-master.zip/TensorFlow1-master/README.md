![alt text](https://raw.githubusercontent.com/Adilmar/TensorFlow1/master/images/banner.jpg)

# TensorFlow - Curso de Introdução ao TensorFlow + Deep Learning

- Ministrante: Adilmar Coelho Dantas (Doutorando em Ciência da Computação)
- Universidade Federal de Uberlândia - MG
- WebSite: www.adilmar.com.br
- Laboratório: www.lipai.facom.ufu.br
- Email: akanehar@gmail.com

# Ementa geral do curso 

- Introdução
- Tensores e seções TF
- Introdução a machine Learning
- Redes Neurais - Introdução
- Criando sua primeira rede neural com Tensorflow
- Deep Learning - Detecção de sentimentos em frases

